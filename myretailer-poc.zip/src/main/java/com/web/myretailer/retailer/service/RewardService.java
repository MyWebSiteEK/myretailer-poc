package com.web.myretailer.retailer.service;

import com.web.myretailer.retailer.model.Transaction;
import org.springframework.stereotype.Service;

import java.time.Month;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class RewardService {

    // 1. Core Logic to calculate points for a single transaction
    private long calculatePoints(double amount) {
        long points = 0;

        if (amount > 100) {
            // 2 points for every dollar over $100
            points += (long) ((amount - 100) * 2);
            // Plus 1 point for every dollar between $50 and $100 (which is 50 points)
            points += 50;
        } else if (amount > 50) {
            // 1 point for every dollar between $50 and $100
            points += (long) (amount - 50);
        }

        return points;
    }

    // 2. Aggregation Logic
    public Map<Long, Map<String, Object>> getRewardsReport(List<Transaction> transactions) {
        Map<Long, Map<String, Object>> response = new HashMap<>();

        // Group transactions by Customer ID
        Map<Long, List<Transaction>> transactionsByCustomer = transactions.stream()
                .collect(Collectors.groupingBy(Transaction::getCustomerId));

        // Process each customer
        transactionsByCustomer.forEach((customerId, customerTransactions) -> {
            Map<String, Object> customerData = new HashMap<>();

            // Calculate points per month
            Map<Month, Long> pointsPerMonth = customerTransactions.stream()
                    .collect(Collectors.groupingBy(
                            t -> t.getDate().getMonth(),
                            Collectors.summingLong(t -> calculatePoints(t.getAmount()))
                    ));

            // Calculate total points
            long totalPoints = pointsPerMonth.values().stream().mapToLong(Long::longValue).sum();

            customerData.put("monthlyPoints", pointsPerMonth);
            customerData.put("totalPoints", totalPoints);

            response.put(customerId, customerData);
        });

        return response;
    }
}