package com.web.myretailer.retailer.controller;

import com.web.myretailer.retailer.model.Transaction;
import com.web.myretailer.retailer.service.RewardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/rewards")
public class RewardController {

    @Autowired
    private RewardService rewardService;

    @GetMapping
    public Map<Long, Map<String, Object>> getRewards() {
        // Mock Data: 3 Month period
        List<Transaction> transactions = Arrays.asList(
                // Customer 1: $120 purchase (90 pts) in Jan
                new Transaction(1L, 1L, 120.0, LocalDate.of(2023, 1, 15)),
                // Customer 1: $80 purchase (30 pts) in Feb
                new Transaction(2L, 1L, 80.0, LocalDate.of(2023, 2, 20)),

                // Customer 2: $200 purchase (250 pts) in Mar
                // Logic: (200-100)*2 + 50 = 200 + 50 = 250
                new Transaction(3L, 2L, 200.0, LocalDate.of(2023, 3, 10))
        );

        return rewardService.getRewardsReport(transactions);
    }
}