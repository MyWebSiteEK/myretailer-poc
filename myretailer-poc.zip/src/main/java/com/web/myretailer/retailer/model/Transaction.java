package com.web.myretailer.retailer.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import java.time.LocalDate;

@Data
@AllArgsConstructor
public class Transaction {
    private Long id;
    private Long customerId;
    private double amount;
    private LocalDate date;
}